﻿
using System;
namespace DungeonCrawler.Services
{
    public interface IFileHelper
    {
        string GetLocalFilePath(string filename);

    }
}
